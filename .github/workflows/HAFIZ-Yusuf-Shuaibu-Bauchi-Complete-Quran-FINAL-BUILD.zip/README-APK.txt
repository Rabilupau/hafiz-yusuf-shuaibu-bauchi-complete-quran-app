Qur’an Audio – Android APK Project
Published by: Rabilu Muhammad
Reciter: Hafiz Yusuf Shuaibu Bauchi
Version: 1.0.0

This Android wrapper contains the current Qur’an Audio web app from the supplied SPCK ZIP.

Important:
- Current audio folder contains 001.mp3 only. Add 002.mp3 through 114.mp3 when available.
- The project is ready to build as an APK using Android Studio or AndroidIDE with internet access.
- Open this folder as an Android/Gradle project and run the app or build a debug APK.
